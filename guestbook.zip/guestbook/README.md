Laravel Guestbook

Developed using Laravel Framework 7.30.6

Developed using PHP 7.2.5

To Install Composer Packages

1)Go to cmd or terminal
2)Make sure you are in the right path (project folder directory)
3)use cd project_name to go inside the folder and cd .. to go back up out of the folder
4)In the terminal use the command composer install 
5)Your vendor folder is installed


NOTE: If you dont have composer  already, to Install it https://getcomposer.org/download/

Refer: https://laravel.com/

To view the login page.
http://127.0.0.1:8000/login

Run Migrations & Seeders 
php artisan migrate
php artisan db:seed

You can also register as a new user and login.
please refer user table for admin credentials.

To run PHP Unit Tests  
php artisan test
